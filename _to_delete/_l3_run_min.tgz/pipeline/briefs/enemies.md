# Content brief: enemies
_Generated 2026-11-03T15:17:48.969Z by pipeline/brief.mjs. Regenerate with `node pipeline/brief.mjs enemies`; do not hand-edit._

**Writer agent:** enemy-designer-agent  |  **Output dir:** `content/enemies/`  |  **Produces:** Rust enemy roster beyond the Tier 0 grunt: role, behaviour, telegraph, stat block.

## Rules (non-negotiable)
1. Ground every item in the GDD. Cite corpus chunk ids in `sources` (ids are the `[...]` tags below). Cite only chunks you actually used.
2. Never invent lore silently. If the GDD states it, `status: "canon"`. If you are extending it, `status: "proposed"` and fill `gddGap` (which gap, why it fits). The owner approves proposals.
3. Authority order when sources disagree: **primary** (owner's GDD docx) > **derived** (specs in design/) > **reference** (PDF drafts, review kit, README). The GDD pitch contains the typo "Rush": the name is **Rust**. The city is **the Fallen City**.
4. Voice: hopeful, energetic, full of personality; Zed's side warm and plain-spoken; the Rust cold and official but always answered or defaced by the community. Never grim, gory, sneering or military. Enemies are pushed back or knocked down, never killed.
5. Numbers stay in engine units and near the engine's Tier 0 values (see engine files). Do not edit anything under `src/`.
6. Banned patterns (the validator rejects them): `\bRush\b` (typo for "Rust" (the GDD pitch has this typo; never copy it)); `\bRusts\b` ("the Rust" is a collective: no "Rusts"); `\bFallen\b(?!\s+City)` ("Fallen" alone; say "the Fallen City"); `\bfallen city\b` (lower-case city name; write "Fallen City"); `\b(driven|pushed|kicked|cleared)\s+out\s+of\s+the\s+Rust\b|\bthe Rust (zone|area|smell|stain)\b` (Rust treated as a place or stain; it is a force of people); `\b(TARGETS? ELIMINATED|MISSION COMPLETE|HOSTILES? NEUTRALI[SZ]ED|NEUTRALI[SZ]E)\b` (military/clinical phrasing on Zed's side); `\b(YOU DIED|PATHETIC|LOSER|GAME OVER)\b` (gloating or grim lose-screen copy); `\b(gore|gory|blood|bloody|corpse|dismember\w*|brains|entrails|slaughter\w*|massacre\w*)\b` (gore; tone is never gory); `\b(kill|kills|killed|killing|murder\w*)\b` (lethal wording; enemies are knocked down / pushed back).
7. Write JSON files to `content/enemies/` (one item object or an array per file, UTF-8). Then run `node pipeline/validate.mjs enemies` and fix every error before you report back.

## Schema
Each item has these fields:
```json
{
  "id": "string, kebab-case, unique within its type",
  "status": "one of canon | proposed",
  "gddGap": "string; REQUIRED when status is \"proposed\", otherwise omit",
  "sources": "array of corpus chunk ids (at least 1)",
  "name": "string",
  "role": "one of grunt | bruiser | ranged | support | elite | boss",
  "tier": "integer 0-3 (0 = Tier 0 prototype; later tiers are expansions)",
  "description": "string, what the player sees (uniform, visor, cold hue, boxy shapes - Rust look)",
  "behaviour": "string, how its AI differs from the grunt (chase, circle, attacker-slot rules)",
  "telegraph": "string, the readable wind-up the player reacts to",
  "weakness": "string, how the player is meant to beat it",
  "spriteKey": "string, dotted asset key like \"rust.enforcer\" (see assets/asset-keys.json)",
  "stats": "{ maxHp, moveSpeed, attackRange, telegraphMs, attackMs, recoverMs, damage, knockback, hitstun } - all positive numbers, same units as src/enemies/gruntData.js"
}
```
Example:
```json
{
  "id": "rust-enforcer",
  "status": "proposed",
  "gddGap": "GDD names one enemy type first; asks for dynamic enemy behaviours later",
  "name": "Rust Enforcer",
  "role": "bruiser",
  "tier": 1,
  "description": "...",
  "behaviour": "...",
  "telegraph": "...",
  "weakness": "...",
  "spriteKey": "rust.enforcer",
  "stats": {
    "maxHp": 60,
    "moveSpeed": 70,
    "attackRange": 80,
    "telegraphMs": 600,
    "attackMs": 300,
    "recoverMs": 900,
    "damage": 14,
    "knockback": 320,
    "hitstun": 300
  },
  "sources": [
    "the-rebellion#4"
  ]
}
```

## Already exists (extend, don't duplicate)
- `rust-brick-dugan` "Brick" Dugan (content/enemies/mini-bosses.json)
- `rust-railgun-royce` "Railgun" Royce (content/enemies/mini-bosses.json)
- `rust-crusher-kane` "Crusher" Kane (content/enemies/mini-bosses.json)
- `rust-glitch` "Glitch" (content/enemies/mini-bosses.json)
- `rust-raptor` "Raptor" (content/enemies/mini-bosses.json)
- `rust-holts-experiment-subject-88` Dr. Holt's Experiment "Subject 88" (content/enemies/mini-bosses.json)
- `rust-commander-atlas` Commander Atlas (content/enemies/mini-bosses.json)
- `rust-sentinel-x9` Sentinel-X9 (content/enemies/mini-bosses.json)
- `rust-iron-line-cordon` Rust Iron Line Cordon (content/enemies/rust-gdd-units.json)
- `rust-breaker` Rust Breaker (content/enemies/rust-gdd-units.json)
- `rust-watcher` Rust Watcher (content/enemies/rust-gdd-units.json)
- `rust-copper-fang` Rust Copper Fang (content/enemies/rust-gdd-units.json)
- `rust-halden-varr` Overseer Halden Varr (content/enemies/rust-gdd-units.json)
- `rust-overseer-voss` Overseer Kade Voss (content/enemies/rust-gdd-units.json)
- `rust-overseer-calder` Overseer Rhea Calder (content/enemies/rust-gdd-units.json)
- `rust-overseer-wren` Overseer Silas Wren (content/enemies/rust-gdd-units.json)
- `rust-voss-drone` Rust Surveillance Drone (content/enemies/rust-gdd-units.json)
- `rust-voss-megadrone` Rust MegaDrone (content/enemies/rust-gdd-units.json)
- `rust-hologram-decoy` Rust Hologram Decoy (content/enemies/rust-gdd-units.json)
- `rust-elite-drone` Rust Elite Drone (content/enemies/rust-gdd-units.json)
- `rust-specialist` Rust Specialist - The Copper Fangs (content/enemies/rust-gdd-units.json)
- `rust-ranger` Rust Ranger (content/enemies/rust-gdd-units.json)
- `rust-grunt` Rust Grunt (content/enemies/rust-roster.json)

## Uncovered GDD names (write these FIRST)
_none detected. Still add new items: pick open questions from design/lore/canon.md or the Focus line, mark them `proposed`._


## Engine / spec files to stay compatible with
#### src/enemies/gruntData.js
```
// Rust grunt data table (Tier 0). Placeholder numbers; tune here only.
// Times in milliseconds, speeds in px/s, rects relative to the entity origin (facing right).
// maxHp and attack damage/knockback/hitstun are read from src/shared/combatData.js (single source).
// Sprite key mirrors assets/asset-keys.json sprites["rust.grunt"]. src/config/assetKeys.js does
// not export it yet (outside my folders), so it is declared here.
import { COMBAT_DEFAULTS, GRUNT_ATTACK_COMBAT } from '../shared/combatData.js';

export const GRUNT_SPRITE_KEY = 'rust.grunt';
export const GRUNT_ANIMS = {
  idle: 'rust.grunt.idle',
  approach: 'rust.grunt.walk',
  telegraph: 'rust.grunt.telegraph',
  attack: 'rust.grunt.attack',
  hitstun: 'rust.grunt.hit',
  dead: 'rust.grunt.ko',
  recover: 'rust.grunt.idle',
};

// Rust Jab 1-2-3. atMs = when each hit-request is emitted, measured from the start of the attack state.
// Per-hit numbers are the shared grunt attack numbers from combatData.js.
const JAB_STRING = Object.freeze([70, 150, 240].map((atMs) => Object.freeze({
  atMs,
  damage: GRUNT_ATTACK_COMBAT.attack.damage,
  knockback: GRUNT_ATTACK_COMBAT.attack.knockback,
  hitstun: GRUNT_ATTACK_COMBAT.attack.hitstun,
})));

// Attack variants (parry mix-up). One is picked per attack, before the wind-up, so the cue can show which it is.
//   holdMs   : extra wind-up before the swing (the pose is held; the closing ring simply takes longer)
//   hits     : hit-requests, atMs from the start of the attack state (same animation, same total length as the plain string)
//   markIndex: the hit the cue ring is aimed at (the one worth parrying); kind 'finisher' draws it orange
// The ring always closes PARRY_CUE_LEAD_MS before its hit, so "press parry when the ring closes" is right for every variant.
export const PARRY_CUE_LEAD_MS = 80;
const LIGHT_HITS = JAB_STRING;
// Missing the ring is punished: the heavy finisher and the flurry after it PIERCE the player's 400 ms post-hit invulnerability
// (otherwise a landed first jab would swallow them), so an unparried finisher is a real combo. A parry stuns the grunt and
// cancels every hit still to come, so the flurry only happens when the finisher was not parried (blocked = chip damage only).
export const FLURRY = Object.freeze({ damage: 6, knockback: 150, hitstun: 250, count: 2, gapMs: 90 });
const FINISHER_AT = JAB_STRING[2].atMs;
const FINISHER_HITS = Object.freeze([
  JAB_STRING[0], JAB_STRING[1],
  Object.freeze({ atMs: FINISHER_AT, pierceInvuln: true,
    damage: GRUNT_ATTACK_COMBAT.attack.damage * 2,
    knockback: Math.round(GRUNT_ATTACK_COMBAT.attack.knockback * 1.6),
    hitstun: Math.round(GRUNT_ATTACK_COMBAT.attack.hitstun * 1.5) }),
  ...Array.from({ length: FLURRY.count }, (_, i) => Object.freeze({
    atMs: FINISHER_AT + FLURRY.gapMs * (i + 1), pierceInvuln: true,
    damage: FLURRY.damage, knockback: FLURRY.knockback, hitstun: FLURRY.hitstun })),
]);
const ATTACK_TAIL_MS = 150;
const variant = (id, weight, holdMs, hits, markIndex, kind) => Object.freeze({
  id, weight, holdMs, hits, markIndex, kind, attackMs: hits[hits.length - 1].atMs + ATTACK_TAIL_MS,
});
export const ATTACK_VARIANTS = Object.freeze([
  variant('string', 3, 0, LIGHT_HITS, 0, 'strike'),
  variant('hold', 2, 260, LIGHT_HITS, 0, 'strike'),
  variant('finisher', 3, 0, FINISHER_HITS, 2, 'finisher'),
  variant('hold-finisher', 1, 260, FINISHER_HITS, 2, 'finisher'),
]);

/** Weighted pick that never repeats lastId back to back. rng: () => [0,1). */
export function pickAttackVariant(rng = Math.random, lastId = null, variants = ATTACK_VARIANTS) {
  const pool = variants.filter((v) => v.id !== lastId);
  const total = pool.reduce((n, v) => n + v.weight, 0);
  let r = rng() * total;
  for (const v of pool) { r -= v.weight; if (r < 0) return v; }
  return pool[pool.length - 1];
}

export const GRUNT = {
  team: 'rust',
  spriteKey: GRUNT_SPRITE_KEY,
  maxHp: COMBAT_DEFAULTS.GRUNT_MAX_HP,
  moveSpeed: 135,
  circleSpeed: 85,
  laneTolerance: 22,    // max vertical (depth) offset at which an attack may start; otherwise close the gap in y first
  attackRange: 70,      // distance to target at which an attack may start
  circleRadius: 180,    // hold at this distance when no attacker slot is free
  spawnIdleMs: 250,     // idle after spawn before chasing
  telegraphMs: 360,     // visible wind-up before the hit (keep >= 300 for readability)
  attackMs: JAB_STRING[JAB_STRING.length - 1].atMs + 150, // total attack state length: last jab + follow-through
  jabString: JAB_STRING, // 1-2-3 Rust Jab: one hit-request per entry, each with its own attackId
  variants: ATTACK_VARIANTS, // parry mix-up patterns; RustGrunt uses plain jabString unless it is given a pickVariant
  recoverMs: 200,
  hitstunMinMs: 300,
  knockbackDecay: 600,  // px/s^2
  hurtbox: { x: -20, y: -80, w: 40, h: 80 },
  attack: {
    hitbox: { x: 20, y: -65, w: 55, h: 40 },
    damage: GRUNT_ATTACK_COMBAT.attack.damage,
    knockback: GRUNT_ATTACK_COMBAT.attack.knockback,
    hitstun: GRUNT_ATTACK_COMBAT.attack.hitstun,
  },
};

// Max grunts that may be in telegraph/attack at once; others circle.
export const ATTACKER_CAP = 2;
```

#### assets/asset-keys.json
```
{
  "_note": "Owner: art-direction-agent. PLACEHOLDER paths; keep keys stable, swap files for final art. Resolution 1280x720. Paths relative to project root.",
  "version": 1,
  "ui": {
    "ui.bar.health.frame": "assets/ui/bar-frame-health.svg",
    "ui.bar.health.fill": "assets/ui/bar-fill-health.svg",
    "ui.bar.timer.frame": "assets/ui/bar-frame-timer.svg",
    "ui.button.default": "assets/ui/button-default.svg",
    "ui.button.hover": "assets/ui/button-hover.svg",
    "ui.button.pressed": "assets/ui/button-pressed.svg",
    "ui.button.disabled": "assets/ui/button-disabled.svg",
    "ui.panel": "assets/ui/panel.svg",
    "ui.icon.heart": "assets/ui/icon-heart.svg",
    "ui.icon.clock": "assets/ui/icon-clock.svg",
    "ui.card.victory": "assets/ui/victory-card-frame.svg"
  },
  "sprites": {
    "zed": "assets/sprites/zed/Idle/rotations/east.png",
    "rust.grunt": "assets/sprites/Rust Bruisers walking/rotations/east.png",
    "rust.iron-line-cordon": null,
    "rust.breaker": "assets/sprites/Rust Bruisers walking/rotations/east.png",
    "rust.watcher": "assets/sprites/Rust Rangers — “The Watchers/Idle/rotations/east.png",
    "rust.copper-fang": "assets/sprites/Rust Specialists — “The Copper Fangs/Idle/rotations/east.png",
    "rust.halden-varr": null,
    "rust.overseer-voss": null,
    "rust.overseer-calder": null,
    "rust.overseer-wren": null,
    "rust.drone": null,
    "rust.megadrone": null,
    "rust.hologram": null,
    "rust.elite-drone": null
  },
  "animations": {
    "zed": [
      "zed.idle",
      "zed.walk",
      "zed.jump",
      "zed.light",
      "zed.heavy",
      "zed.hit",
      "zed.ko"
    ],
    "rust.grunt": [
      "rust.grunt.idle",
      "rust.grunt.walk",
      "rust.grunt.telegraph",
      "rust.grunt.attack",
      "rust.grunt.hit",
      "rust.grunt.ko",
      "rust.grunt.telegraph.headbutt",
      "rust.grunt.attack.headbutt",
      "rust.grunt.telegraph.jab-combo",
      "rust.grunt.attack.jab-combo"
    ],
    "rust.iron-line-cordon": [
      "rust.iron-line-cordon.idle",
      "rust.iron-line-cordon.walk",
      "rust.iron-line-cordon.telegraph.push-bar-sweep",
      "rust.iron-line-cordon.attack.push-bar-sweep",
      "rust.iron-line-cordon.hit",
      "rust.iron-line-cordon.ko",
      "rust.iron-line-cordon.telegraph.headbutt",
      "rust.iron-line-cordon.attack.headbutt"
    ],
    "rust.breaker": [
      "rust.breaker.idle",
      "rust.breaker.walk",
      "rust.breaker.telegraph.gauntlet-smash",
      "rust.breaker.attack.gauntlet-smash",
      "rust.breaker.hit",
      "rust.breaker.ko",
      "rust.breaker.telegraph.rust-uppercut",
      "rust.breaker.attack.rust-uppercut",
      "rust.breaker.telegraph.body-check",
      "rust.breaker.attack.body-check"
    ],
    "rust.watcher": [
      "rust.watcher.idle",
      "rust.watcher.walk",
      "rust.watcher.telegraph.taser-shot",
      "rust.watcher.attack.taser-shot",
      "rust.watcher.hit",
      "rust.watcher.ko",
      "rust.watcher.telegraph.baton-strike",
      "rust.watcher.attack.baton-strike"
    ],
    "rust.copper-fang": [
      "rust.copper-fang.idle",
      "rust.copper-fang.walk",
      "rust.copper-fang.telegraph.gauntlet-lunge",
      "rust.copper-fang.attack.gauntlet-lunge",
      "rust.copper-fang.hit",
      "rust.copper-fang.hit.shield",
      "rust.copper-fang.transition.shield-break",
      "rust.copper-fang.telegraph.fang-jab",
      "rust.copper-fang.attack.fang-jab",
      "rust.copper-fang.telegraph.copper-cross",
      "rust.copper-fang.attack.copper-cross",
      "rust.copper-fang.telegraph.shield-bash",
      "rust.copper-fang.attack.shield-bash",
      "rust.copper-fang.p2.idle",
      "rust.copper-fang.p2.walk",
      "rust.copper-fang.p2.telegraph.hook",
      "rust.copper-fang.p2.attack.hook",
      "rust.copper-fang.p2.hit",
      "rust.copper-fang.p2.ko",
      "rust.copper-fang.p2.telegraph.fang-jab",
      "rust.copper-fang.p2.attack.fang-jab",
      "rust.copper-fang.p2.telegraph.copper-cross",
      "rust.copper-fang.p2.attack.copper-cross"
    ],
    "rust.halden-varr": [
      "rust.halden-varr.idle",
      "rust.halden-varr.walk",
      "rust.halden-varr.telegraph.authority-strike",
      "rust.halden-varr.attack.authority-strike",
      "rust.halden-varr.hit",
      "rust.halden-varr.telegraph.command-shield",
      "rust.halden-varr.hold.command-shield",
      "rust.halden-varr.hit.shield",
      "rust.halden-varr.telegraph.command-override",
      "rust.halden-varr.attack.command-override",
      "rust.halden-varr.telegraph.adaptive-counter",
      "rust.halden-varr.stance.anti-air",
      "rust.halden-varr.stance.anti-rush",
      "rust.halden-varr.stance.anti-combo",
      "rust.halden-varr.transition.phase2",
      "rust.halden-varr.p2.idle",
      "rust.halden-varr.p2.walk",
      "rust.halden-varr.p2.telegraph.authority-strike",
      "rust.halden-varr.p2.attack.authority-strike",
      "rust.halden-varr.p2.hit",
      "rust.halden-varr.p2.ko",
      "rust.halden-varr.p2.telegraph.rust-collapse",
      "rust.halden-varr.p2.attack.rust-collapse",
      "rust.halden-varr.p2.telegraph.breaker-slam",
      "rust.halden-varr.p2.attack.breaker-slam",
      "rust.halden-varr.p2.telegraph.taser-shot",
      "rust.halden-varr.p2.attack.taser-shot",
      "rust.halden-varr.p2.telegraph.fang-combo",
      "rust.halden-varr.p2.attack.fang-combo",
      "rust.halden-varr.p2.telegraph.drone-command",
      "rust.halden-varr.p2.attack.drone-command"
    ],
    "rust.overseer-voss": [
      "rust.overseer-voss.idle",
      "rust.overseer-voss.walk",
      "rust.overseer-voss.hit",
      "rust.overseer-voss.ko",
      "rust.overseer-voss.telegraph.predictive-strike",
      "rust.overseer-voss.attack.predictive-strike",
      "rust.overseer-voss.telegraph.drone-swarm",
      "rust.overseer-voss.attack.drone-swarm",
      "rust.overseer-voss.telegraph.hologram-decoy",
      "rust.overseer-voss.attack.hologram-decoy",
      "rust.overseer-voss.telegraph.data-spike",
      "rust.overseer-voss.attack.data-spike",
      "rust.overseer-voss.transition.phase2",
      "rust.overseer-voss.p2.telegraph.predictive-lockdown",
      "rust.overseer-voss.p2.attack.predictive-lockdown",
      "rust.overseer-voss.p2.telegraph.hologram-assault",
      "rust.overseer-voss.p2.attack.hologram-assault",
      "rust.overseer-voss.p2.telegraph.drone-fusion",
      "rust.overseer-voss.p2.attack.drone-fusion",
      "rust.overseer-voss.p2.telegraph.system-crash",
      "rust.overseer-voss.p2.attack.system-crash",
      "rust.overseer-voss.p2.idle",
      "rust.overseer-voss.p2.walk",
      "rust.overseer-voss.p2.hit",
      "rust.overseer-voss.p2.ko",
      "rust.overseer-voss.p2.telegraph.predictive-strike",
      "rust.overseer-voss.p2.attack.predictive-strike",
      "rust.overseer-voss.p2.telegraph.drone-swarm",
      "rust.overseer-voss.p2.attack.drone-swarm",
      "rust.overseer-voss.p2.telegraph.hologram-decoy",
      "rust.overseer-voss.p2.attack.hologram-decoy",
      "rust.overseer-voss.p2.telegraph.data-spike",
      "rust.overseer-voss.p2.attack.data-spike"
    ],
    "rust.overseer-calder": [
      "rust.overseer-calder.idle",
      "rust.overseer-calder.walk",
      "rust.overseer-calder.hit",
      "rust.overseer-calder.ko",
      "rust.overseer-calder.telegraph.forge-hammer",
      "rust.overseer-calder.attack.forge-hammer",
      "rust.overseer-calder.telegraph.hydraulic-grab",
      "rust.overseer-calder.attack.hydraulic-grab",
      "rust.overseer-calder.telegraph.steam-burst",
      "rust.overseer-calder.attack.steam-burst",
      "rust.overseer-calder.hold.steam-burst",
      "rust.overseer-calder.telegraph.conveyor-trap",
      "rust.overseer-calder.attack.conveyor-trap",
      "rust.overseer-calder.transition.phase2",
      "rust.overseer-calder.p2.telegraph.furnace-slam",
      "rust.overseer-calder.p2.attack.furnace-slam",
      "rust.overseer-calder.prop.arm-punch",
      "rust.overseer-calder.prop.arm-grab",
      "rust.overseer-calder.p2.idle",
      "rust.overseer-calder.p2.walk",
      "rust.overseer-calder.p2.hit",
      "rust.overseer-calder.p2.ko",
      "rust.overseer-calder.p2.telegraph.forge-hammer",
      "rust.overseer-calder.p2.attack.forge-hammer",
      "rust.overseer-calder.p2.telegraph.hydraulic-grab",
      "rust.overseer-calder.p2.attack.hydraulic-grab",
      "rust.overseer-calder.p2.telegraph.steam-burst",
      "rust.overseer-calder.p2.attack.steam-burst",
      "rust.overseer-calder.p2.hold.steam-burst",
      "rust.overseer-calder.p2.telegraph.conveyor-trap",
      "rust.overseer-calder.p2.attack.conveyor-trap"
    ],
    "rust.overseer-wren": [
      "rust.overseer-wren.idle",
      "rust.overseer-wren.walk",
      "rust.overseer-wren.hit",
      "rust.overseer-wren.ko",
      "rust.overseer-wren.telegraph.grapple-dash",
      "rust.overseer-wren.attack.grapple-dash",
      "rust.overseer-wren.perch",
      "rust.overseer-wren.airborne",
      "rust.overseer-wren.telegraph.skyline-snare",
      "rust.overseer-wren.attack.skyline-snare",
      "rust.overseer-wren.telegraph.silent-step",
      "rust.overseer-wren.telegraph.rooftop-execution",
      "rust.overseer-wren.attack.rooftop-execution",
      "rust.overseer-wren.land.rooftop-execution",
      "rust.overseer-wren.idle.cloak",
      "rust.overseer-wren.walk.cloak",
      "rust.overseer-wren.p2.telegraph.grapple-clone",
      "rust.overseer-wren.p2.attack.grapple-clone",
      "rust.overseer-wren.p2.telegraph.shadow-pulse",
      "rust.overseer-wren.p2.attack.shadow-pulse",
      "rust.overseer-wren.p2.telegraph.vanish-storm",
      "rust.overseer-wren.p2.attack.vanish-storm",
      "rust.overseer-wren.p2.silhouette.vanish-storm",
      "rust.overseer-wren.p2.idle",
      "rust.overseer-wren.p2.walk",
      "rust.overseer-wren.p2.hit",
      "rust.overseer-wren.p2.ko",
      "rust.overseer-wren.p2.telegraph.grapple-dash",
      "rust.overseer-wren.p2.attack.grapple-dash",
      "rust.overseer-wren.p2.perch",
      "rust.overseer-wren.p2.airborne",
      "rust.overseer-wren.p2.telegraph.skyline-snare",
      "rust.overseer-wren.p2.attack.skyline-snare",
      "rust.overseer-wren.p2.telegraph.silent-step",
      "rust.overseer-wren.p2.telegraph.rooftop-execution",
      "rust.overseer-wren.p2.attack.rooftop-execution",
      "rust.overseer-wren.p2.land.rooftop-execution",
      "rust.overseer-wren.p2.idle.cloak",
      "rust.overseer-wren.p2.walk.cloak"
    ],
    "rust.drone": [
      "rust.drone.idle",
      "rust.drone.telegraph",
      "rust.drone.attack",
      "rust.drone.hit",
      "rust.drone.ko",
      "rust.drone.p2.idle",
      "rust.drone.p2.telegraph",
      "rust.drone.p2.attack",
      "rust.drone.p2.hit",
      "rust.drone.p2.ko"
    ],
    "rust.megadrone": [
      "rust.megadrone.idle",
      "rust.megadrone.spawn",
      "rust.megadrone.telegraph.sweeping-laser",
      "rust.megadrone.attack.sweeping-laser",
      "rust.megadrone.hit",
      "rust.megadrone.ko",
      "rust.megadrone.turn"
    ],
    "rust.hologram": [
      "rust.hologram.idle",
      "rust.hologram.walk",
      "rust.hologram.spawn",
      "rust.hologram.ko",
      "rust.hologram.telegraph.punch",
      "rust.hologram.attack.punch"
    ],
    "rust.elite-drone": [
      "rust.elite-drone.idle",
      "rust.elite-drone.telegraph",
      "rust.elite-drone.attack",
      "rust.elite-drone.hit",
      "rust.elite-drone.ko",
      "rust.elite-drone.spawn"
    ]
  },
  "fx": {
    "fx.spark": "generated in code (ArenaScene._ensureSparkTexture)",
    "fx.rage.entry.lines.spec": "design/art/rage-entry-flash.md"
  },
  "hitFeedbackSpec": "design/art/hit-feedback-spec.md",
  "menu": {
    "menu.sky": "assets/menu/menu-sky.svg",
    "menu.buildings.far": "assets/menu/menu-buildings-far.svg",
    "menu.buildings.near": "assets/menu/menu-buildings-near.svg",
    "menu.street": "assets/menu/menu-street.svg",
    "menu.wall": "assets/menu/menu-wall.svg",
    "menu.strip.a": "assets/menu/strip-torn-a.svg",
    "menu.strip.b": "assets/menu/strip-torn-b.svg",
    "menu.strip.c": "assets/menu/strip-torn-c.svg",
    "menu.poster.heroes": "assets/menu/poster-local-heroes.svg",
    "menu.poster.curfew": "assets/menu/poster-curfew.svg"
  },
  "menuPalette": {
    "brick": "#9C3B2E",
    "brickDark": "#7A2F25",
    "mustard": "#E1A92B",
    "forest": "#2F5D3A",
    "brown": "#6B4A2F",
    "cream": "#E8DCC0",
    "nearBlack": "#1D1A16"
  },
  "menuFonts": {
    "display": "Anton, Impact, sans-serif",
    "mono": "'Courier Prime', 'Courier New', monospace"
  },
  "enemySpriteSpec": "design/art/enemy-sprite-specs.md"
}
```

#### design/art/style-guide.md
```
# The Rebellion: Style Guide (Tier 0)

Status: DRAFT, pending art style approval (see Open Questions). Target resolution: 1280x720.

## 1. Art style: flat vector world, pixel art Zed

DECISION: Zed (the player character) is hand-authored pixel art. Everything else (Rust enemies, UI, backgrounds, FX, menu) stays flat vector until the owner decides otherwise (see Open Question 1). Zed's spec, prompts and sheet layout: `design/art/zed-pixellab-prompt.md`.

Zed pixel rules:
- 128x128 frame, ~96px figure, facing right, feet at bottom-centre.
- Selective 1px outline #2E1F16, 2 to 3 flat tones per colour, light from top left, no gradients, no dithering, no blur, no anti-aliasing.
- Palette limited to the Hope palette in section 2 (Mustard, Mustard Light, Warm Brown, Skin Brown, Dark Brown, Cream, small Brick Red and Forest Green accents); no Rust or combat-signal colours.
- Render the sprite with nearest-neighbour filtering (Phaser `pixelArt` or per-texture `setFilter(NEAREST)`), and keep sprite scale an integer so pixels stay square.
- The ground shadow is not baked in; the game draws the flat 25 percent black ellipse.

The rest of this section describes the flat-vector style for everything that is not Zed.

Flat-vector shapes with a thick dark outline, 2 to 3 tone cel shading, no gradients, no textures.

Why not pixel art:
- Agent-built project: SVG and simple shape rigs can be generated and edited as text by agents; hand-placed pixels cannot be generated reliably.
- The GDD budgets tokens for "at least one character to move" and an animation lead who owns a large workload. Flat vector is the cheapest path to a consistent look.
- Scales cleanly to 1280x720 and other sizes with no filtering artifacts.
- The theme (murals, bold colour, casual fits) suits big colour blocks and strong silhouettes.
- Placeholders and final art share one language, so swapping is low risk.

Rules: outline 4px at 128px sprite height (scale proportionally; Zed is the exception, 1px pixel outline per the Zed pixel rules above), outline colour #2E1F16 for Zed and the world, #14181C for Rust. Shadows are flat 25 percent black ellipses under every character, drawn by the game at runtime (never baked into any sprite, Zed's included). Light source top left.

## 2. Palette

Hope palette (Zed, world, UI):

| Name | Hex | Use |
|---|---|---|
| Mustard | #E3A92B | Primary accent, Zed jacket, buttons, timer frame |
| Mustard Light | #F2C04D | Hover, highlights |
| Brick Red | #A8402E | Panel headers, buildings, heart icon, damage, title shadow (`brickRed`) |
| Forest Green | #2F6B3F | Foliage, gardens, murals |
| Health Green | #4C9A55 / #7BC47F | Health fill / highlight |
| Warm Brown | #6B4423 | Ground, trousers, wood |
| Skin Brown | #8A5A3B | Zed skin (placeholder, open to revision) |
| Dark Brown | #2E1F16 | Outlines, text, bar frames |
| Cream | #F4E6C8 | Panels, light text on dark |
| Sand | #F2D9A0 / #E8C27A | Background sky and walls |

Rust palette (enemy, deliberately colder and harsher):

| Name | Hex | Use |
|---|---|---|
| Slate | #3C4650 | Uniform |
| Gunmetal | #2A3138 | Boots, gloves |
| Steel | #7C8A96 | Helmet |
| Visor Cyan | #4FB3D9 | Visor, Rust UI accents |
| Rust Ink | #14181C | Outline |

Combat signal colours (reserved, never used for decoration):

| Name | Hex | Use |
|---|---|---|
| Telegraph Red | #FF3B30 | Enemy attack warning only |
| Overload Violet | #8E5BFF | Enemy phase-2 power glow (Calder, Voss drones, MegaDrone, Varr cracks); owner approved, replaces the GDD's red glow |
| Overload Ice | #BFF4FF | Phase-2 core glow (Varr Rust Collapse charge) |
| Hit White | #FFFFFF | Hit flash |
| Spark Cream | #FFF6D6 | Spark core |
| Low Health | #D9822B then #FF3B30 | Bar at 50 percent and 25 percent |

Contrast: all text must reach 4.5:1 (Cream on Dark Brown ~11:1; Dark Brown on Mustard ~7:1).

## 3. Typography

Street-style set, all Google Fonts under the SIL OFL (licensing confirmed). Real values live in `src/config/assetKeys.js` (`FONTS`).

- Display (game title and large splash text): "Permanent Marker"; fallback `Impact, sans-serif`.
- Buttons and result headings (WIN/LOSE): "Anton"; fallback `Impact, sans-serif`.
- Body and small text: "Rubik" weights 500 and 700; fallback `Arial, sans-serif`.
- Numerals (timer, wave counter): Rubik 700, tabular figures.
- Sizes at 1280x720 (as built in the menu prototype): title 96px, subtitle 32px, button 36px, result heading 72px, HUD label 20px, timer 40px, minimum body 18px.
- Text: Cream with 4px Dark Brown stroke over action; Dark Brown on Mustard/Cream surfaces.

Title treatment: Mustard #E3A92B fill, Dark Brown #2E1F16 outline about 10px, hard Brick Red #A8402E offset shadow 7px right and 7px down with no blur, rotated -2.5 degrees. Subtitle: uppercase Rubik 700, Cream, same -2.5 degree tilt (6px Dark Brown stroke).

Rule: tilt only the title and subtitle. Never rotate HUD, timer, button or other gameplay text.

Font loading: canvas text must not draw before fonts are ready. Call `waitForFonts()` from `src/config/assetKeys.js` before creating text; it waits on `document.fonts.load()` for all three families with a 2.5s cap, then proceeds with the fallbacks.

## 4. UI components

- Button (260x64): Mustard fill, 4px Dark Brown outline, 12px radius, solid dark-mustard drop edge. States: default, hover (#F2C04D), pressed (#C48E1F, shifted down 4px), disabled (#8C8070). Focus ring: 4px Cream outside outline, for keyboard and gamepad. Label centred.
- Health bar (frame 360x32, fill 348x20): Dark Brown frame with Cream 3px border; fill Health Green with a lighter top band. Crop the fill by width (scaleX). Colour shifts at 50 percent and 25 percent. A delayed "chip" bar in Cream shows recent damage for 400ms. Enemy bars use Rust palette (Steel frame, Visor Cyan fill), 96x10, shown only when damaged.
- Timer (frame 160x56): Dark Brown with Mustard border; digits Cream. Last 10 seconds: digits and border pulse Telegraph Red at 2 Hz.
- Panel (560x360): Cream body, Dark Brown 6px outline, Brick Red header strip 48px, 16px radius. Used for pause, win, lose.
- Icons (32x32): flat shapes, 3px Dark Brown outline, one fill colour, rounded joins, no inner detail.
- HUD layout: health top left at (24,24), timer top centre, wave counter top right. Keep 24px safe margin. (ux-flow-designer owns final layout; this is a default.)

## 5. Characters and world

- Zed (pixel art): 128x128 frame, ~96px tall figure, mustard jacket, warm brown trousers, expressive casual fit. Facing right by default; flip for left. Pixel rules in section 1.
- Rust enemies: same frame size, uniform and symmetrical, visor, no personality colour. Contrast through cold hue and straight geometry versus Zed's rounded forms.
- Background: warm, busy mid-ground (corner shop, mural, court hoops, food stall, garden planters), calmer play lane. Background saturation and contrast lower than characters so fighters always pop. Play lane y 440 to 680 stays free of high-contrast detail.

## 6. Do and Don't

Do
- Keep silhouettes distinct: Zed is warm and round, Rust is cold and boxy.
- Reserve Telegraph Red for enemy warnings and the low-time pulse. Enemy bodies never use red; phase-2 power states use Overload Violet (owner decision).
- Use outlines on every interactive or combat element.
- Keep the HUD readable at a glance: bar plus number, big timer.

Don't
- Don't use brick red or red-orange on enemies, which confuses damage and telegraph cues.
- Don't put busy mural detail behind the play lane.
- Don't add gradients, blur, or textures (breaks flat-vector consistency).
- Don't mix pixel art and vector assets, except the approved case: pixel-art Zed over a vector world. Keep Zed's outline colour, palette and flat shading so he still sits in the same scene, and don't apply smoothing filters to him.
- Don't rely on colour alone: telegraphs also use shape (icon) and motion.

## 7. Placeholder policy

Everything currently under `assets/` is a PLACEHOLDER generated shape, not final art. Each file contains a placeholder comment. Replace by overwriting the file at the same path or updating the path in `assets/asset-keys.json`; keys do not change.

## 9. Main menu: Wheatpaste Wall (approved brief: design/ux/menu-concept.md)

Scope: main menu scene only. Same flat-vector rule (flat shapes, no gradients, no glow, no outlines needed on scenery), but edges are torn and uneven (irregular polygons) to read as pasted paper and worn walls.

Menu palette (from the approved brief; takes precedence inside the menu scene):

| Name | Hex | Use |
|---|---|---|
| Brick | #9C3B2E | Wall, Rust notice poster |
| Brick Dark | #7A2F25 | Mortar, poster borders |
| Mustard | #E1A92B | Selected strip, lit windows, subtitle, lane dashes |
| Forest | #2F5D3A | Options strip, vines, poster text |
| Brown | #6B4A2F | Quit strip, door, ledge top |
| Cream | #E8DCC0 | Title text, Controls strip, posters, sun |
| Near-black | #1D1A16 | Title strip, ledge, silhouettes, street |

Scenery-only derived tones (placeholder values, not UI colours): sky bands #B5522F, #D07A2C, #E1A92B, #EBC862; far buildings #5B3A2E; near buildings #2B2420 with windows #3A2F28; street #2A2420.

Palette conflict to resolve: the game palette in section 2 uses Mustard #E3A92B, Brick #A8402E, Forest #2F6B3F, Brown #6B4423, Cream #F4E6C8, Dark Brown #2E1F16. The menu values differ slightly. Menu scene uses the menu set; in-game UI keeps section 2 until the owner chooses one set (open question 8).

Typography (menu): display and buttons "Anton" (heavy condensed; fallback `Impact, sans-serif`); small print, subtitle, footer hint "Courier Prime" (fallback `'Courier New', monospace`). This differs from section 3, where the title uses Permanent Marker and body uses Rubik. Courier Prime is OFL on Google Fonts (not yet loaded in `waitForFonts()`; menu-ui-agent to add). Title cream on near-black strip, tilted about 2 degrees; subtitle mustard monospace. Posters ship with block placeholders in place of text; titles must be live text over the poster sprite (SVG loaded as an image cannot use web fonts).

Strip colours: Fight mustard (selected, brightest), Controls cream, Options forest with cream text, Quit brown with cream text. Strip art is one white torn shape tinted per option. Dark text on mustard and cream; cream text on forest and brown.

Selection feedback: tween rotation to 0 and x +10px over about 100 ms, then the bright variant; mouse hover identical.

Layering (back to front): menu.sky, menu.buildings.far (parallax slow), menu.buildings.near, menu.street (place at y 360), menu.wall (x 0, left half, hides left buildings), posters and strips on the wall. Do: keep the wall busy only where the menu is not; keep text over flat areas. Don't: add glow around the sun or lit windows, gradients, or smooth rounded edges on paper.

## 8. Open questions

1. Art style approval: Zed is pixel art (decided). Open: should Rust enemies, UI and backgrounds also move to pixel art, or stay flat vector next to pixel Zed?
2. Resolution: 1280x720 assumed. Scale mode (FIT?) and whether pixel-perfect scaling is needed.
3. Sprite frame size: 128x128 assumed. Is a larger hero (e.g. 192) wanted?
4. Final animation source for Rust enemies and FX: hand-authored spritesheets, skeletal rig (Spine/DragonBones), or tween-driven vector parts? Zed is settled (hand-authored 36-frame pixel sheet, fixed in the manifest) and is out of scope here; this question only affects the Rust grunt frame counts.
5. Zed's design (skin tone, hair, silhouette, and the "young street hero" read) needs creative sign-off from the GDD owner; current look is a placeholder. The GDD does not state Zed's age, role or backstory (canon.md open question 3).
6. Resolved: fonts. Bangers replaced by Permanent Marker (display), Anton added (buttons, result headings), Rubik kept (body); all OFL. See section 3.
7. Audio sync cues for hits are not in this scope; who owns them?
8. Menu palette vs game palette (section 9 vs section 2): unify on one set? Also confirm Anton plus Courier Prime for the menu.
9. Menu SVGs are placeholders generated by script; final hand-polished art not produced. Brick wall has no texture beyond mortar lines.

## 10. Rage system look (source: GameDesignDocument/Zed Rage System Spec.docx, section 8)

Status: DESIGN SPEC ONLY. No final Rage art has been drawn. Placeholders, when generated, will be labelled placeholder. Asset list and sizes: `asset-manifest.md` section "Rage system". Motion and feedback timings: `hit-feedback-spec.md` section 8.

### 10.1 Rage palette (ember to orange to red-white)

| Name | Hex | Use |
|---|---|---|
| Rage Ember | #7A2E1A | Low fill (0 to 33), aura start |
| Rage Orange | #F58A2A | Mid fill (34 to 66). Same value as the pending "Ember" in hit-feedback-spec 7.5 (owner approval pending) |
| Rage Red | #D62A1E | High fill (67 to 99). Deliberately not Telegraph Red #FF3B30 (enemy warning only) |
| Rage Red-White | #FFE3D6 | Full / READY core, eyes and fists glow core, flash peak |
| Rage Gold | #FFD24A | Gain-pop numbers, spark tips (matches Gold in hit-feedback-spec 7.5) |
| Grief Blue-Grey | #4A5560 | Aura wisps at the base, rage-end ash. Grief turning to fire: wisps start blue-grey and burn to ember as they rise |

The fill is a gradient along the bar length, so the leading edge is always the hottest. Frame outline stays Dark Brown #2E1F16. Rage never uses Overload Violet or Visor Cyan (those belong to Rust). Text on the meter is Cream on Dark Brown (11:1), never on the fill itself.

### 10.2 Meter shape (distinct from health)

Health is a rounded green rectangle with a heart. The Rage meter is a chamfered, slanted-end bar (12 degree lean) with a flame notch at the right tip and an icon slot at the left. It sits directly under the health bar, left-aligned, 8 px gap, and is visually lighter than health so health is always read first. Flat vector like other UI, 1 px Dark Brown outline.

### 10.3 State identity (never colour alone)

| State | Colour | Shape / icon | Motion | Text |
|---|---|---|---|---|
| Building | ember to red ramp | flame icon, plain frame, solid fill | pulse rises with fill, 0.8 Hz to 3 Hz | none |
| READY | red-white | L keycap icon, 4 corner notches and flare on frame, shrinking 4 s strip | capped 2.5 Hz breathing | "READY" |
| Active | red-white to red | fist icon, diagonal hatch fill, jagged top edge | 9 s drain, 2 Hz rising to 4 Hz in last 3 s | seconds left |

Each state differs in icon, fill texture, frame silhouette, pulse speed and text. Pulse speed is also a second channel for how full the meter is.

### 10.4 Zed glow rules

- Building aura: subtle 2 to 3 px rim glow plus occasional ember wisps; opacity 15 percent at 50 fill rising to 35 percent at 99.
- Rage: eyes and both fists glow (Red-White core, Orange halo) for the whole Rage; body aura stronger (50 percent) with rising embers.
- Aura and glows are separate overlay layers, so Zed's sheet is never repainted. They must not hide his silhouette or reduce contrast against enemy telegraphs.

### 10.5 Do and Don't (Rage)

- Do tie every colour change to a shape or text change.
- Do keep one flash per activation.
- Don't strobe, and don't use Telegraph Red or Overload Violet on Rage elements.

### 10.6 Open questions (Rage)

1. Approve the six new colours above (and Ember versus Low Health #D9822B).
2. HUD placement under the health bar is assumed at 1280x720; confirm with the HUD owner.
3. RESOLVED: the Special move frames are 68x68, same as Zed's other in-game sprites, so no scaling is needed. (Earlier note of 48x48 was wrong.)
4. A reduced-motion option is proposed, not in the GDD.
```

## Retrieved GDD passages (26)
### [the-rebellion#5] primary - GameDesignDocument/The Rebellion.docx
[table]
Agent | Technical constraint | Desponds On | Budget
Player Mechanics | Sprite animations for idle, walk, jump; input handling | Asset & Animation Lead | Token coast to make at least one character to move two hundred tokens
Player combos Agent | One state machine for attacks | Player Mechanics | Token Cost to make the combos work 200 tokens
Health & Hitbox Agent | Shared damage, health, and hitbox data that every agent reads | None | Size is medium so medium
Enemy Agent | Chase and attack behaviour, attacker cap, one enemy type first | Health & Hitbox, Asset & Animation / Asset & Animation | It is large as it will run the enemy note
Game State Agent | Win check, lose state, time-out result, retry | Health & Hitbox Agent | Medium cost of token
Wave Spawner | Spawn triggers, rate, cap, and positions | Enemy Agent | 
Asset & Animation Lead | Sprite source, animation list, hit stop, and feedback | None | Large as it runs the Animation
Camera & Bounds Agent (new) | Arena camera lock, world bounds, unreachable-enemy failsafe | Wave Spawner | 
Menu & UI Agent | HUD (health, timer), win/lose screens, menus | Game State, Health & Hitbox | Medium Token use as well
Team Lead agent | Builds the Agent Orchestration |  | 

### [the-rebellion#1] primary - GameDesignDocument/The Rebellion.docx
The Rebellion
Fists of the Fallen City
A Face Paced 2d Side Scrolling Brawler that lets you fight back against Corrupt private security force.
Executives Sections
The Pitch
The Rebellion first of the Fallen city is a Fast-paced 2D side-scrolling brawler where players fight through urban districts overtaken Rust a corrupt private Security Force. The game blends classic beat-‘me-up mechanics with modem combo systems character progression, and dynamic enemy behaviours. Take control of Zed and fight your way through Fallen to get it back. Take control of Zed and fight your way through Fallen City to get it back.
The 3 Pillars of Game Play
[table]
Impactful, Fast-paced combat | Skill depth through combos and Defence | Wave-clearing under pressure
Punchy hits" with light and heavy attacks and pick-up objects, in a fast 2D side-scrolling brawl. | Combos and Juggle routes" on offense, plus block, dodge, and parry on defence. | Enemies spawn in waves, and the player must "Defeat Wave / Clear Arena to win the level in time frame", tracked by the Timer Agent.
The Win and Lose conditions.

### [the-rebellion#8] primary - GameDesignDocument/The Rebellion.docx
Everything changed when RUST, the private security force, swept through the districts. The document describes the city as “overtaken Rust a corrupt private Security Force” — and Zed saw it firsthand.
RUST didn’t arrive like soldiers; they arrived like thieves. They shut down the basketball courts. They fenced off the community gardens. They patrolled the alleys where kids used to play. They tore down murals — including his father’s — replacing them with surveillance towers and propaganda screens.
Zed’s father disappeared after confronting RUST officers during a mural teardown. His mother’s food stall was seized for “security violations.” Friends vanished. Neighbours were beaten. The city’s heartbeat went quiet.
Zed didn’t have a choice. He had to fight.
Why Zed Fights
Zed isn’t a soldier. He’s a kid from a livedin neighbourhood who learned to fight the same way he learned to dance — through rhythm, instinct, and community.
His style reflects the game’s pillars:
Impactful, fast-paced combat — Zed’s punches feel like brickred alley brawls, scrappy but sharp.

### [the-rebellion#10] primary - GameDesignDocument/The Rebellion.docx
Zed embodies the game’s theme: “hopeful, energetic, full of personality and stories.” He’s expressive, stubborn, and fiercely loyal. He cracks jokes mid-fight. He refuses to back down. He carries the city’s colours in his outfit — mustard yellow, brick red, forest green — as a reminder of what he’s fighting for.
Character – the Enemy
Enemy Faction Lore: RUST — The Private Security Force of Fallen City
Overview
Rust began as a private security contractor hired to “stabilize” Fallen City after years of political decay and rising crime. But once they were inside, they never left. Rust transformed from a protective force into a militarized occupation, tightening control over every district and crushing resistance with brutal efficiency.
Their name comes from their signature oxidized metal armour, a symbol of decay — a reminder that Fallen City is rotting under their rule.
Rust’s soldiers are not just guards. They are enforcers, hunters, and executioners. Each unit is trained to suppress civilians, eliminate rebels, and maintain absolute control.
⚙️ Rust’s Origin

### [the-rebellon-gameplay-system#3] primary - GameDesignDocument/The Rebellon gameplay System.docx
HUD: While Zed carries a weapon, the HUD shows a small icon of that weapon with its remaining durability next to the health bar.
Weapon Balance Values
Reference: Starting values, tuned against Zed's current moves (light hits 6, 7 and 12 damage, heavy attack 18 damage with a 12 frame startup) and a Grunt's 30 HP. Frames are at 60 per second. These are first-pass numbers and can be retuned in playtesting.
Baseball bat: Damage 20. Startup 7 frames, active 4, recovery 16. Reach is a hitbox 64 wide. Knockback 400. Hitstun 26 frames. Durability 10 hits. A Grunt goes down in 2 hits.
Pipe: Damage 24. Startup 12 frames, active 4, recovery 20. Reach is a hitbox 84 wide, the longest in the game. Knockback 360. Hitstun 28 frames. Durability 8 hits. A Grunt goes down in 2 hits.

### [the-rebellion#3] primary - GameDesignDocument/The Rebellion.docx
[table]
Agent | Development role | Gameplay Effect
Player Mechanics agent | Movement, jump, input handling | The player moves and feels responsive
Player combos Agent | One state machine for attacks, combos, cancel windows, hit stun | Light and heavy attacks chain into combos
Enemy Agent | Control the A.I Enemies | This will control the Enemies in the game
Game State Agent | Win check, lose state, time-out result, retry | Clear the arena to win; fail and retry have rules
Wave Spawner | Win check, lose state, time-out result, retry | Difficulty comes from how waves arrive
Asset & Animation Lead | Sprite source, animation list, hit stop and feedback | Punchy hits" and readable telegraphs
Health & Hitbox Agent | Owns health, damage values, and hitbox/hurt box data | Hits land, damage registers, the player can die
Camera & Bounds Agent (new) | Arena camera lock, world bounds, unreachable-enemy failsafe | Prevents the off-screen soft lock
Menu & UI Agent | Builds and owns every screen and on-screen element the player sees outside the arena action |  | The player can start a game, read the state of the fight, and see why they won or lost

### [the-rebellon-gameplay-system#1] primary - GameDesignDocument/The Rebellon gameplay System.docx
The Rebellion
Fists of the Fallen City
Game Play Systems
Weapon System
Starting in Level 2, weapon boxes are introduced across the levels, giving players access to baseball bats and pipes for combating Grunt enemies
How it works
From Level 2 onwards, Zed can break weapon boxes, pick up baseball bats and pipes using the pickup animation, and carry them using the carrying animation before attacking enemies.
Weapon Rules
Damage: Bats and pipes hit harder than Zed's heavy attack.
Speed and reach: The baseball bat has a quick swing. The pipe has a longer reach but a slower startup.
Durability: Each weapon wears out after a set number of hits. Exact hit counts are listed under Weapon Balance Values.
Breakage: When a weapon runs out of hits it breaks, a short break effect plays, and Zed goes back to using his fists.
Throwing: Zed can throw a carried weapon. A thrown weapon spins through the air and damages the first enemy it hits. Throwing costs durability and the weapon can be picked up again if it survives, see Weapon Balance Values.

### [the-rebellon-gameplay-system#2] primary - GameDesignDocument/The Rebellon gameplay System.docx
Dropping: There is no drop button. Zed drops a carried weapon when he is hit more than 3 times while carrying it, which means the weapon drops on the 4th hit. A dropped weapon lies on the floor and Zed can pick it up again. It keeps its remaining durability. Picking the weapon back up does not reset the hit count.
Attacks with a weapon: Weapons use the existing light and heavy attack buttons. There are no new inputs and no separate weapon move set. The light and heavy mentioned in the core mechanics refer to Zed's light and heavy attacks, not to light and heavy objects.
Weapon types: Only the baseball bat and the pipe exist for now. There are no other weapons or upgraded versions.
Weapon boxes: Each level from Level 2 has one weapon box in a fixed placement. The box holds one weapon, either a baseball bat or a pipe. Which weapon it holds is fixed for each level and is chosen by the level designer. It is not random. Boxes do not respawn.
Enemy use: Weapons are for Zed only. Enemies cannot pick up or use weapons.

### [the-rebellon-gameplay-system#4] primary - GameDesignDocument/The Rebellon gameplay System.docx
Light and heavy buttons: The light button swings the weapon at the values above. The heavy button does the same swing with 25 percent more damage and 25 percent more knockback, and costs 2 durability instead of 1. The heavy swing deals 25 damage with the bat and 30 damage with the pipe. A heavy swing still goes through when the weapon has only 1 durability left, and the weapon breaks afterwards.
Thrown weapon: Damage 15, knockback 300, hitstun 20 frames. It travels at 480 pixels per second for up to 320 pixels and hits the first enemy in its path. A throw costs 2 durability, the same as a heavy swing. If the weapon still has durability left after the throw, it lands on the floor where it hit an enemy or at the end of its flight, and Zed can pick it up and keep using it until its durability runs out. If the weapon has 2 durability or less when thrown, the throw still goes through and the weapon breaks when it lands, with the same break effect as a worn-out weapon.
Weapon box: A weapon box breaks after 2 hits from Zed. The box break animation is added separately.

### [hit-feedback-spec#5] derived - design/art/hit-feedback-spec.md - 3. Enemy telegraphs (readable at a glance)
- Strike frame is the hitbox-on frame; active for 80ms, then recovery 300ms during which the enemy is vulnerable (gives the punish window).
- Attacker cap: only the enemies currently attacking can show a cue; waiting enemies circle in neutral colours, so a ring means "this one is about to land its heavy hit".
- Telegraph Red `#FF3B30` is reserved for attack warnings (ground danger zones) and must not be used for any other effect. The finisher ring uses Finisher Orange `#FFA41C`.
- Do not interrupt a windup by hit-stop on other characters.

### [hit-feedback-spec#4] derived - design/art/hit-feedback-spec.md - 3. Enemy telegraphs (readable at a glance)
Every Rust attack must be avoidable, blockable or parryable by a player who reacts to the cue.
| Attack | Windup | Cues |
|---|---|---|
| Grunt basic strike | 400ms (24f) minimum; never below 300ms | 1) 3-frame anticipation pose (arm pulled back, body leaning away) 2) 1px-wider outline 3) finisher attacks only (the heavy third hit of a Rust string): an orange ring (Finisher Orange `#FFA41C`, runtime only) opens around the enemy about a third of the way into the windup and closes onto it 80ms before the heavy hit, so the player presses parry as it closes. No telegraph icon, no body tint, no flash. Missing the ring is punished: the heavy hit and a 2-hit flurry after it ignore the player's post-hit invulnerability (6 damage each, after the 16-damage finisher); a parry stuns the grunt and cancels the flurry, a block reduces all of it to chip damage. Plain-jab attacks have no ring and are read from the pose alone |
| Heavy or later enemies | 600ms | same pose and outline cues, ground danger zone ellipse in red at 30 percent alpha |

### [enemy-sprite-specs#25] derived - design/art/enemy-sprite-specs.md - 5. Unit specs
Conventions in the unit tables: Tel = Telegraph, Atk = Attack. Wind-up ms from the unit JSON. "Key pose" = what the silhouette must show at the peak of the wind-up.

### [enemy-sprite-specs#9] derived - design/art/enemy-sprite-specs.md - 1.4 Folders, files, keys (mirrors Zed's layout)
- Unit folder: sprite key with dots replaced by dashes: `assets/sprites/rust-grunt/`, `assets/sprites/rust-iron-line-cordon/`, `rust-breaker`, `rust-watcher`, `rust-copper-fang`, `rust-halden-varr`, `rust-overseer-voss`, `rust-overseer-calder`, `rust-overseer-wren`, `rust-drone`, `rust-megadrone`, `rust-hologram`, `rust-elite-drone`.
- State folder (PascalCase, underscore separates state and move): `Idle`, `Walk`, `Hit`, `Ko`, `Telegraph`, `Attack`, `Telegraph_GauntletSmash`, `Attack_GauntletSmash`, `Hold_SteamBurst`, `Transition_Phase2`, and so on. Phase-2 variants carry a `P2_` prefix: `P2_Idle`, `P2_Telegraph_RustCollapse`.
- Key pose (one static image per state, used for the Phaser texture before animations register, and as a fallback): `assets/sprites/<unit>/<State>/rotations/east.png` and `west.png`. For Telegraph states the key pose is the peak wind-up frame; for Attack states it is the strike frame; for other states it is frame 000.
- Animation frames: `assets/sprites/<unit>/<State>/animations/<state-lowercase>/<dir>/frame_000.png`, `frame_001.png`, ... (3-digit, zero based, same as `zedFramePath`).
- Example, Breaker smash wind-up: `assets/sprites/rust-breaker/Telegraph_GauntletSmash/rotations/east.png` and `.../Telegraph_GauntletSmash/animations/telegraph_gauntlet-smash/west/frame_004.png`. The animations subfolder name is the folder name lowercased with moves in kebab case.
- Phaser texture key (like `zedTextureKey`): `<spriteKey>.<state>[.<move>][.p2].<dir>`; frame key adds `.<i>`. Animation key (what `asset-keys.json` lists): `rust.breaker.telegraph.gauntlet-smash`, `rust.copper-fang.p2.telegraph.hook`. Direction suffix `.east` / `.west` is appended by the loader exactly as Zed's (`zed.run.east`). Move ids are kebab case (`gauntlet-smash`).
- The grunt's existing default clips keep their keys (`rust.grunt.telegraph`, `rust.grunt.attack`); later grunt moves add `.headbutt`, `.jab-combo`.
- `assets/asset-keys.json` lists every animation key per unit (generated from the same table as this spec). The enemy-owner's data table (like `gruntData.js`) maps its states to these keys.

### [enemy-sprite-specs#26] derived - design/art/enemy-sprite-specs.md - 5.1 rust.grunt (established)
- Frame 128x128, figure 52x96 (scale 1.00, 0.87 of Zed). Folder `assets/sprites/rust-grunt/`.
- Look: slate uniform, steel helmet, cyan visor, cheap oxidised plating kept to cold slate; boxy, symmetrical, no personal marks. Silhouette: square helmet on a square torso, arms straight to the sides.
- Palette: Slate, Slate Light, Gunmetal (boots, gloves), Steel (helmet), Visor Cyan, Rust Ink.
- Core clips (24 frames): Idle 4 (weight shift), Walk 6, Telegraph 3 (450 ms, arm pulled back, torso leaning away), Attack 4 (250 ms; hit-active frame 2, frame 4 open recovery), Hit 2, Ko 5.
- Extra (16): Telegraph_Headbutt 3 (short wind-up, chin tucked) / Attack_Headbutt 4 (forward lunge, helmet leads); Telegraph_JabCombo 3 / Attack_JabCombo 6 (three 2-frame punches; hit-active frames 2, 4, 6). Timings for those two moves are not set (engine does not implement them yet).
- Telegraph key pose: the strike arm cocked fully behind the back line, body lean past the foot line, visibly longer silhouette than Idle.

### [canon#3] derived - design/lore/canon.md - Factions
- **Zed and the neighbourhood:** warm, rounded, casual, expressive. Fights back to get the city back.
- **The Rust:** a force of people (uniform, symmetrical, visor, cold hue, boxy). Cold, harsh, official. Not a place, a smell, a stain or a status effect. Per the GDD they turned from a protective force into a militarized occupation that crushes resistance with brutal efficiency: "enforcers, hunters, and executioners", each unit trained to suppress civilians, eliminate rebels and maintain absolute control. Breakers use illegal muscle stimulants; Copper Fangs undergo psychological conditioning; recruits are given serial numbers.

### [style-guide#9] derived - design/art/style-guide.md - 5. Characters and world
- Zed (pixel art): 128x128 frame, ~96px tall figure, mustard jacket, warm brown trousers, expressive casual fit. Facing right by default; flip for left. Pixel rules in section 1.
- Rust enemies: same frame size, uniform and symmetrical, visor, no personality colour. Contrast through cold hue and straight geometry versus Zed's rounded forms.
- Background: warm, busy mid-ground (corner shop, mural, court hoops, food stall, garden planters), calmer play lane. Background saturation and contrast lower than characters so fighters always pop. Play lane y 440 to 680 stays free of high-contrast detail.

### [win#8] derived - design/ux/win.md - Data needs
Delivered once with `round-won` or in a `round-stats` event (proposed), so the screen does not need to read live game state.
| Data | Type | Source | Notes |
|---|---|---|---|
| `winReason` | enum: `arena-cleared` (Tier 0 only value) | Game State | Future: `reached-exit` |
| `wavesCleared` | number | Wave Spawner / Game State | |
| `waveTotal` | number | Wave Spawner | |
| `enemiesDefeated` | number | Enemy / Game State | |
| `secondsRemaining` | number | Timer | Value at the moment of the win |
| `timeLimitSeconds` | number | Game State | For the "(of 02:00)" text |
| `currentHealth` | number | Health & Hitbox | At the moment of the win |
| `maxHealth` | number | Health & Hitbox | |

### [contracts#3] derived - design/team/contracts.md - Rules
- `team`: `'player' | 'rust'`. Hits only affect the opposing team.
- Hitbox/hurtbox rects are relative to the entity origin, authored facing right; combat mirrors them when `facing = -1`.
- `attackId` is unique per swing. combat ignores a repeat (attackId, target) pair, so one swing hits a target once.
- Player id is `'player'`. Enemy ids unique (e.g. `grunt-1`).
- Player/enemy own movement and animation; combat owns hp, hit-stun and invulnerability flags. On `damage-applied` the target applies knockback and plays hurt; on `entity-died` it plays death and removes itself, then emits `entity-unregistered`.
- `getState()` may include optional `guard: 'parry' | 'block' | null`, read by combat at hit time. parry: damage negated, `damage-applied` still emitted with `amount: 0, knockback: 0, hitstun: 0` and unchanged `hpAfter` (no hp change, no invulnerability consumed). block: damage x `BLOCK_DAMAGE_MULT` (0.25, min 1), knockback x `BLOCK_KNOCKBACK_MULT` (0.25), hitstun 0. Dedupe per (attackId, target) still applies.
- Invulnerable or dead targets take no damage and emit no `damage-applied`.
- After `round-won`/`round-lost`, combat ignores `hit-request` until `retry`.
- On `retry`: state resets timer/state, combat resets all hp and clears registrations' flags. waves restarts at wave 1; player/enemy respawn and re-emit `entity-registered`.
- All damage and health numbers live in `src/combat/`, `src/shared/combatData.js`, or move/enemy data tables. Nobody hard-codes them elsewhere. Round constants: `src/state/config.js`.

### [the-rebellion-final-gdd#4] reference - PDf/The Rebellion- Final Gdd.pdf
Agent Technical Desponds Budget constraint On Player Sprite Asset & Token coast to Mechanics animations for Animation make at least idle, walk, jump; Lead one character to input handling move two hundred tokens Player combos One state Player Token Cost to Agent machine for Mechanics make the attacks combos work 200 tokens Health & Shared damage, None Size is medium Hitbox Agent health, and so medium hitbox data that every agent reads Enemy Agent Chase and Health & It is large as it attack Hitbox, will run the behaviour, Asset & enemy note attacker cap, Animation one enemy type Asset & first Animation Game State Win check, lose Health & Medium cost of Agent state, time-out Hitbox token result, retry Agent Wave Spawner Spawn triggers, Enemy rate, cap, and Agent positions Asset & Sprite source, None Large as it runs Animation Lead animation list, the Animation hit stop, and feedback Camera & Arena camera Wave Bounds Agent lock, world Spawner (new) bounds, unreachable- enemy failsafe Menu & UI HUD (health, Game State, Medium Token Agent timer), win/lose Health & use as well screens, menus Hitbox

### [adversarial-qa#10] reference - gdd-review-kit-main/reviews/adversarial-qa.md - 2. CONNECTIONS
**My Finding 2 (unbounded spawns, infinite juggles) plus the Player Psychologist's Finding 4 (no cap on simultaneous attackers, no telegraphs).** Together they describe a specific unfair-death loop. Spawns with no caps and no rules for how many enemies may attack at once, combined with parry and dodge that need telegraphs the document never mentions, produce crowd deaths the player cannot read. The Psychologist sees this as churn. I add that the same missing cap is an exploit vector in the other direction: a player who juggles one enemy indefinitely can hold the rest of the wave in a passive state, if the AI waits its turn. The absent attacker cap therefore produces a cheap loss for new players and a stall win for experienced ones.

### [feasibility-lead#11] reference - gdd-review-kit-main/reviews/feasibility-lead.md - 2. CONNECTIONS
**Defensive kit dependency chain (Business Analyst F3, Player Psychologist F4, my F3/F4).** Parry and dodge need enemy attack telegraphs. Telegraphs need enemy animation. Enemy animation is unbudgeted. The Enemy Agent has a one-line brief and is depended on by parry, spawn rules (QA F2) and the attacker cap (Psychologist F4). So the Enemy Agent is the most overloaded and least specified component in the document, and no colleague states that in one place.
**Health, damage and hitbox state (Systems Designer F4) and QA F1.** No agent owns health, damage or hitbox/hurtbox data. It is the shared state that every agent reads and writes, and it is also the missing input to the lose condition. This is the most likely integration failure point.
**Timer time-out (Player Psychologist F2, Narrative Critic F3, QA F1).** Three lenses agree that time-out has no defined outcome. For the build, that means the Game Loop Agent has no defined transition on the most common failure event, so retry granularity (whole level or current wave) cannot be implemented.

### [feasibility-lead#2] reference - gdd-review-kit-main/reviews/feasibility-lead.md - Finding 2: Feature list far exceeds the budgeted work
- Problem: The Game Mechanics section promises combos, juggle routes, block/dodge/parry, pick-up objects, wave spawning, timed levels, "character progression" and "dynamic enemy behaviours". The budget covers only "at least 1 character to move" and "the combos work". Nothing is allocated to defensive tools, juggling, pickups, progression, enemy AI, art, audio, or level content.
- Passage: "Combos and Juggle routes", "Defensive tools(block dodge, parry)", "character progression, and dynamic enemy behaviours" versus a two-line budget table.
- Severity: MAJOR. Juggle physics and parry timing windows are hard to tune, and the document doesn't say what gets cut first.

### [systems-designer#2] reference - gdd-review-kit-main/reviews/systems-designer.md - Finding 2: Progression is promised but has no defined system (BLOCKING)
**Problem:** The pitch claims "modern combo systems, character progression, and dynamic enemy behaviours". The systems sections do not mention progression. There are no stats, unlocks, upgrades, moves gained over time, level count, or difficulty ramp. Pacing across a full playthrough cannot be assessed because the document never says how long a playthrough is or how a level differs from the last. The "Corrupt private security force" is the only enemy described, and there are no enemy types, bosses or districts beyond "urban districts".
**Source:** The pitch sentence above, and the absence of any progression, level list or enemy roster anywhere else in the document.

### [player-psychologist#4] reference - gdd-review-kit-main/reviews/player-psychologist.md - Finding 4: Difficulty curve, death/failure handling, and player feedback are absent
**Problem:** Brawlers commonly lose players through cheap damage, unreadable enemy attacks, and crowding. The document says enemies "spawn to fight" and are "dynamic" but gives no enemy types, attack telegraphs, limits on how many can attack at once, or difficulty ramp. It also does not say what happens on death (lives, checkpoints, continues), how health is shown, or how the game makes hits feel good beyond the phrase "punchy hits". Players will not know why they lost, which is a primary churn driver.
**Source:** "Enemies spawn to fight"; "Enemy Agent: This will control the Enemies in the game"; the "Impactful Combat – punchy hits" bullet. Nothing about health, lives, difficulty, or telegraphing.
**Severity:** MAJOR

### [business-analyst#2] reference - gdd-review-kit-main/reviews/business-analyst.md - Finding 2: Pitch promises a full-featured brawler, but the scoped systems cover only movement, combos, a timer, and a win check
- **Problem:** The pitch claims "character progression" and "dynamic enemy behaviours". It also claims "urban districts", pick-up objects, and a "modern combo system". None of the progression is specified, and the district and level structure is not specified either. The Agent table lists only five agents: movement, combos, timer, enemy, and game loop. Progression, pick-ups, districts, and levels have no owner, no budget, and no content plan. The listed scope is a tech demo, but the pitch sells a shippable game. Those are two different products with two different costs.
- **Source:** The Pitch ("character progression, and dynamic enemy behaviours"; "urban districts"). Game Mechanics ("pick-up objects"). AI Architecture Team table (five agents, none covering progression or content).
- **Severity:** MAJOR

### [the-rebellion-final-gdd#3] reference - PDf/The Rebellion- Final Gdd.pdf
Enemy Agent Control the A.I This will control the Enemies Enemies in the game Game State Agent Win check, lose Clear the arena to state, time-out win; fail and retry result, retry have rules Wave Spawner Win check, lose Difficulty comes state, time-out from how waves result, retry arrive Asset & Animation Sprite source, Punchy hits" and Lead animation list, hit readable telegraphs stop and feedback Health & Hitbox Owns health, Hits land, damage Agent damage values, and registers, the player hitbox/hurt box data can die Camera & Bounds Arena camera lock, Prevents the off- Agent (new) world bounds, screen soft lock unreachable-enemy failsafe Menu & UI Agent Builds and owns The player can every screen and on- start a game, read screen element the the state of the player sees outside fight, and see why the arena action they won or lost Technical Strategy

## Need more?
`node pipeline/search.mjs "<query>" -k 8 --full` searches all 841 chunks across 86 documents.
