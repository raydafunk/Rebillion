// Rust Ranger sprite data. No Phaser. Art lives in assets/sprites/Rust Rangers — “The Watchers/ (8 directions each):
//   Idle/rotations/<dir>.png (48px), Idle/animations/idle_breathing (8 frames, 68px), Shield_Strike (9 frames, 68px),
//   stun_taking_a_hit/Taking_Punch (6 frames, 80px), falling_backward_aft (9 frames, 68px). There is no walk cycle in the set,
//   so the idle-breathing loop stands in for walking.
// Used for every enemy whose skin is 'rust-ranger' (Level 3 wave 2, Level 4 Ranger waves). Gameplay is the grunt's; the kind in
// enemyKinds.js adds the health and speed. Same contract as breakerType2Data.js.
import { DIRECTIONS, directionFromVelocity } from './breakerData.js';

export const RANGER_SKIN = 'rust-ranger';
export const RANGER_SPRITE_KEY = 'rust.ranger';
export const RANGER_DIR = 'assets/sprites/Rust Rangers — “The Watchers';
export const RANGER_DIRS = DIRECTIONS;
export const RANGER_WALK_FRAMES = 8;
export const RANGER_WALK_FPS = 10;
export const RANGER_ATTACK_FRAMES = 9;
export const RANGER_ATTACK_MS = 570;
export const RANGER_HIT_FRAMES = 6;
export const RANGER_DEATH_FRAMES = 9;
export const RANGER_DEATH_DEFAULT_FPS = 30;
export const RANGER_DEATH_MS = 700;
export const RANGER_WALK_FOLDER = 'Idle/animations/idle_breathing';
export const RANGER_ATTACK_FOLDER = 'Shield_Strike/animations/The_character_pulls_the_shield_arm_back_tightly_ag';
export const RANGER_HIT_FOLDER = 'stun_taking_a_hit/animations/Taking_Punch';
export const RANGER_DEATH_FOLDER = 'falling_backward_aft/animations/The_character_recoils_violently_backward_as_if_str';

const pad = (i) => String(i).padStart(3, '0');
// Watchers share the Ranger art (one sprite set, "Rust Rangers — The Watchers"); they keep their own stats in enemyKinds.js.
export const RANGER_ART_SKINS = Object.freeze([RANGER_SKIN, 'rust-watcher']);
export const isRanger = (skin) => RANGER_ART_SKINS.includes(skin);

export const rangerRotationKey = (dir) => `${RANGER_SPRITE_KEY}.rot.${dir}`;
export const rangerWalkFrameKey = (dir, i) => `${RANGER_SPRITE_KEY}.walk.${dir}.${i}`;
export const rangerWalkAnimKey = (dir) => `${RANGER_SPRITE_KEY}.walk.${dir}`;
export const rangerAttackFrameKey = (dir, i) => `${RANGER_SPRITE_KEY}.attack.${dir}.${i}`;
export const rangerAttackAnimKey = (dir) => `${RANGER_SPRITE_KEY}.attack.${dir}`;
export const rangerHitFrameKey = (dir, i) => `${RANGER_SPRITE_KEY}.hit.${dir}.${i}`;
export const rangerHitAnimKey = (dir) => `${RANGER_SPRITE_KEY}.hit.${dir}`;
export const rangerDeathFrameKey = (dir, i) => `${RANGER_SPRITE_KEY}.death.${dir}.${i}`;
export const rangerDeathAnimKey = (dir) => `${RANGER_SPRITE_KEY}.death.${dir}`;

export const rangerRotationPath = (dir) => `${RANGER_DIR}/Idle/rotations/${dir}.png`;
export const rangerWalkFramePath = (dir, i) => `${RANGER_DIR}/${RANGER_WALK_FOLDER}/${dir}/frame_${pad(i)}.png`;
export const rangerAttackFramePath = (dir, i) => `${RANGER_DIR}/${RANGER_ATTACK_FOLDER}/${dir}/frame_${pad(i)}.png`;
export const rangerHitFramePath = (dir, i) => `${RANGER_DIR}/${RANGER_HIT_FOLDER}/${dir}/frame_${pad(i)}.png`;
export const rangerDeathFramePath = (dir, i) => `${RANGER_DIR}/${RANGER_DEATH_FOLDER}/${dir}/frame_${pad(i)}.png`;
export const rangerDeathTimeScale = () => (RANGER_DEATH_FRAMES * 1000 / RANGER_DEATH_DEFAULT_FPS) / RANGER_DEATH_MS;

/** Same contract as breaker2Pose (breakerType2Data.js), with Ranger keys. Strikes, hits and falls are horizontal: east or west by facing; all have real west frames. */
export function rangerPose(e) {
  const face = e.facing < 0 ? 'west' : 'east';
  if (e.state === 'attack') return { anim: rangerAttackAnimKey(face), dir: face, once: true };
  if (e.state === 'hitstun') return { anim: rangerHitAnimKey(face), dir: face, once: true, hit: true, frames: RANGER_HIT_FRAMES, rotation: rangerRotationKey(face) };
  if (e.state === 'dead') return { anim: rangerDeathAnimKey(face), dir: face, once: true, death: true, rotation: rangerRotationKey(face), deathTimeScale: rangerDeathTimeScale() };
  const dir = e.state === 'telegraph' ? null : directionFromVelocity(e.vx || 0, e.vy || 0);
  if (dir) return { anim: rangerWalkAnimKey(dir), dir };
  return { rotation: rangerRotationKey(face), dir: face };
}
